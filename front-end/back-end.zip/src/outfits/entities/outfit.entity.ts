export class Outfit {}
