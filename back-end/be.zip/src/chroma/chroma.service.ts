import { Injectable, OnModuleInit } from '@nestjs/common';
import { ChromaClient, Collection } from 'chromadb';

@Injectable()
export class ChromaService implements OnModuleInit {
    private client: ChromaClient;
    private collection: Collection;

    async onModuleInit() {
        this.client = new ChromaClient({ path: process.env.CHROMADB_URL || 'http://localhost:8000' });

        this.collection = await this.client.getOrCreateCollection({
            name: 'wardrobe_items',
        });
    }

    /**
     * Lưu Vector vào ChromaDB
     */
    async upsertItemVector(
        itemId: string,
        vector: number[],
        metadata: Record<string, any>,
        textDocument: string
    ) {
        await this.collection.upsert({
            ids: [itemId],          // BẮT BUỘC dùng chung ID với MongoDB
            embeddings: [vector],   // Mảng số lấy từ Gemini
            metadatas: [metadata],  // Lưu kèm metadata để sau này filter (VD: userId)
            documents: [textDocument] // (Tùy chọn) Lưu lại chuỗi text gốc
        });
    }

    /**
     * Xóa Vector khi User xóa item ở MongoDB
     */
    async deleteItemVector(itemId: string) {
        await this.collection.delete({
            ids: [itemId]
        });
    }

}
